'''
Drill 3
Write a program that:

Creates a zip file called portfolio_backup.zip in your Documents folder
Adds all .py files from your python_portfolio folder and subfolders to the zip
Prints how many files were added
Then opens the zip and prints the list of all files inside it using namelist()
'''

from pathlib import Path
import zipfile, os

file_path = Path.home()
location = file_path / 'Documents'
location = Path(location)
walk_here = file_path / 'Documents' / 'python_portfolio'

zip_filename = 'Python_Backups.zip'
#zip_filename(location)
backup_zip = zipfile.ZipFile(zip_filename, 'w')
amount = 0
for folder_name, subfolders, filenames in os.walk(walk_here):
    folder_name = Path(folder_name)
    for filename in filenames:
        if filename.endswith('.py'):
            backup_zip.write(folder_name / filename)
            amount +=1
backup_zip.close()
print ("total files added: ", amount)
print(os.cwd)
extract_zip = zipfile.ZipFile('Python_Backups.zip')#(backup_zip)
extract_zip.namelist()
#print(backup_zip)
extract_zip.close()


'''
def backup_to_zip(folder):
    folder = Path(folder)  # Make sure folder is a Path object, not string.
  ❶ number = 1
  ❷ while True:
        zip_filename = Path(folder.parts[-1] + '_' + str(number) + '.zip')
        if not zip_filename.exists():
            break
        number = number + 1
    print('Done.')

backup_to_zip(Path.home() / 'spam')
'''







