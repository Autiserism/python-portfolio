'''
Drill 3
Write a program that:

Creates a zip file called portfolio_backup.zip in your Documents folder
Adds all .py files from your python_portfolio folder and subfolders to the zip
Prints how many files were added
Then opens the zip and prints the list of all files inside it using namelist()
'''

from pathlib import Path
import zipfile, os

file_path = Path.home()
walk_here = file_path / 'Documents' / 'python_portfolio'

zip_filename = 'Python_Backups.zip'

backup_zip = zipfile.ZipFile(zip_filename, 'w')
amount = 0
for folder_name, subfolders, filenames in os.walk(walk_here):
    folder_name = Path(folder_name)
    for filename in filenames:
        if filename.endswith('.py'):
            backup_zip.write(folder_name / filename)
            amount +=1
backup_zip.close()
print ("total files added: ", amount)

extract_zip = zipfile.ZipFile('Python_Backups.zip')
extract_zip.extractall()
print(extract_zip)
extract_zip.close()












