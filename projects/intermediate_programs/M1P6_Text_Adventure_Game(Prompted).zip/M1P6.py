#!/usr/bin/env python3
"""
The Branching Halls  -- a tick-based text dungeon crawler  (project M1P6)

Run:  put this file and the *.json files in one folder, then:  python3 M1P6.py

All balance numbers live in config.json. All room/monster/item text lives in the
other .json files. This file is pure logic; tweak the JSON to retune or reskin.
"""

import json
import random
from pathlib import Path
from collections import deque

# --------------------------------------------------------------------------- #
#  Data loading
# --------------------------------------------------------------------------- #

DATA_DIR = Path(__file__).resolve().parent
DATA = {}
CFG = {}

_FILES = [
    "config", "monsters", "trap_room", "chest_encounters", "safe_rooms",
    "random_encounter", "boss_room", "win_exit", "items",
]


def _load(name):
    with open(DATA_DIR / f"{name}.json", "r", encoding="utf-8") as fh:
        return json.load(fh)


def load_all():
    global CFG
    for name in _FILES:
        DATA[name] = _load(name)
    CFG = DATA["config"]


# --------------------------------------------------------------------------- #
#  Control-flow exceptions (unwind nested loops cleanly)
# --------------------------------------------------------------------------- #

class PlayerDead(Exception):
    pass


class OutOfTime(Exception):
    pass


# --------------------------------------------------------------------------- #
#  Game state
# --------------------------------------------------------------------------- #

class Game:
    def __init__(self, mode, seq):
        self.mode = mode            # "easy" | "hard" | "endless"
        self.seq = seq              # list of single-char digit strings
        self.ticks = CFG["start_ticks"]
        self.log = deque(maxlen=10)
        self.player = {
            "hp": CFG["player_max_hp"],
            "max_hp": CFG["player_max_hp"],
            "dph": CFG["player_dph"],
            "crit": CFG["crit_chance"],
            "stunned": 0,
            "windup_hits": 0,       # consecutive hits landed during the monster's wind-up
            "inventory": [],
        }
        self.stats = {k: 0 for k in (
            "rooms_cleared", "monsters_killed", "bosses_killed", "items_found",
            "traps_sprung", "traps_disarmed", "ambushes", "chests_opened",
            "searches",
        )}
        for iid in CFG.get("starting_kit", []):
            self.player["inventory"].append(iid)


# --------------------------------------------------------------------------- #
#  Resource spenders  (the only places ticks / hp change)
# --------------------------------------------------------------------------- #

def spend(g, n=1):
    for _ in range(n):
        g.ticks -= 1
        if g.ticks <= 0:
            g.ticks = 0
            raise OutOfTime()


def vulnerability(g):
    """Damage-taken multiplier that grows as you go deeper (per difficulty)."""
    sc = CFG["scaling"][g.mode]
    mult = 1.0 + sc["vulnerability_per_room"] * g.stats["rooms_cleared"]
    return min(sc["vulnerability_max"], mult)


def hurt(g, amount):
    g.player["hp"] -= amount
    if g.player["hp"] <= 0:
        g.player["hp"] = 0
        raise PlayerDead()


def add_log(g, msg):
    g.log.append(msg)


# --------------------------------------------------------------------------- #
#  Display helpers
# --------------------------------------------------------------------------- #

def clear():
    print("\033[2J\033[H", end="")


def bar(cur, mx, width=22, fill="\u2588", empty="\u2591"):
    mx = max(mx, 1)
    cur = max(0, min(cur, mx))
    n = int(round(width * cur / mx))
    return fill * n + empty * (width - n)


def render_hud(g):
    clear()
    print("=" * 58)
    print(f" HP   [{bar(g.player['hp'], g.player['max_hp'])}] "
          f"{g.player['hp']}/{g.player['max_hp']}")
    print(f" TIME [{bar(g.ticks, CFG['start_ticks'])}] {g.ticks}")
    line = (f" Cleared: {g.stats['rooms_cleared']}    Mode: {g.mode.upper()}"
            f"    Pack: {len(g.player['inventory'])} item(s)")
    vuln = vulnerability(g)
    if vuln > 1.0:
        line += f"    Peril: x{vuln:.2f}"
    print(line)
    print("-" * 58)
    for line in list(g.log)[-6:]:
        print(f"  . {line}")
    print("=" * 58)


def ask(text, valid):
    valid = [v.lower() for v in valid]
    while True:
        try:
            raw = input(text).strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            raise SystemExit(0)
        if raw and raw[0] in valid:
            return raw[0]
        print("  (choose: " + ", ".join(valid) + ")")


def pause(msg="  (press Enter to continue)"):
    try:
        input(msg)
    except (EOFError, KeyboardInterrupt):
        print("\nGoodbye.")
        raise SystemExit(0)


# --------------------------------------------------------------------------- #
#  Items / inventory
# --------------------------------------------------------------------------- #

def item_blurb(it):
    c = it["category"]
    if c == "healing":
        return f"heal {it['heal']} HP"
    if c == "time":
        return f"+{it['ticks']} ticks"
    if c == "boost":
        return it.get("desc", "permanent boost")
    return ""


def roll_loot(g):
    items = DATA["items"]["items"]
    ids = list(items.keys())
    weights = [items[i].get("weight", 10) for i in ids]
    return random.choices(ids, weights=weights, k=1)[0]


def give_item(g, iid):
    g.player["inventory"].append(iid)
    g.stats["items_found"] += 1
    return DATA["items"]["items"][iid]["name"]


def apply_item(g, iid):
    it = DATA["items"]["items"][iid]
    cat = it["category"]
    if cat == "healing":
        before = g.player["hp"]
        g.player["hp"] = min(g.player["max_hp"], g.player["hp"] + it["heal"])
        add_log(g, f"You use the {it['name']} (+{g.player['hp'] - before} HP).")
    elif cat == "time":
        g.ticks += it["ticks"]
        add_log(g, f"You use the {it['name']} (+{it['ticks']} ticks).")
    elif cat == "boost":
        if "dph" in it:
            g.player["dph"] += it["dph"]
        if "max_hp" in it:
            g.player["max_hp"] += it["max_hp"]
            g.player["hp"] += it["max_hp"]
        if "crit" in it:
            g.player["crit"] += it["crit"]
        add_log(g, f"You use the {it['name']} -- {it.get('desc', 'boost applied')}.")


def consume(g, iid):
    g.player["inventory"].remove(iid)   # removes first occurrence
    apply_item(g, iid)


def _grouped_inventory(g):
    seen, counts = [], {}
    for iid in g.player["inventory"]:
        if iid not in counts:
            seen.append(iid)
            counts[iid] = 0
        counts[iid] += 1
    return seen, counts


def choose_item(g):
    """List the pack and return a chosen item id, or None to back out."""
    if not g.player["inventory"]:
        print("   (your pack is empty)")
        return None
    seen, counts = _grouped_inventory(g)
    for n, iid in enumerate(seen, 1):
        it = DATA["items"]["items"][iid]
        print(f"   {n}. {it['name']} x{counts[iid]}  -- {item_blurb(it)}")
    while True:
        try:
            raw = input("   pick # (or [b]ack): ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            raise SystemExit(0)
        if raw[:1] == "b":
            return None
        if raw.isdigit() and 1 <= int(raw) <= len(seen):
            return seen[int(raw) - 1]
        print("   (enter a listed number, or b)")


def inventory_menu(g):
    """Open the pack outside combat. Opening costs a tick; each use costs a tick."""
    if not g.player["inventory"]:
        add_log(g, "Your pack is empty.")
        return
    spend(g, CFG["tick_costs"]["item_open"])
    while True:
        render_hud(g)
        print(" Your pack:")
        iid = choose_item(g)
        if iid is None:
            return
        spend(g, CFG["tick_costs"]["item_use"])
        consume(g, iid)
        if not g.player["inventory"]:
            return


# --------------------------------------------------------------------------- #
#  Combat
# --------------------------------------------------------------------------- #

def make_monster(g, kind):
    base = DATA["monsters"][kind]
    names = base.get("names", [kind.title()])
    sc = CFG["scaling"][g.mode]
    depth = g.stats["rooms_cleared"]
    hp = int(round(base["hp"] * (1.0 + sc["monster_hp_per_room"] * depth)))
    dmg = int(round(base["dmg"] * (1.0 + sc["monster_dmg_per_room"] * depth)))
    return {
        "kind": kind,
        "name": random.choice(names),
        "hp": hp,
        "max_hp": hp,
        "dmg": dmg,
        "atk_min": base["atk_min"],
        "atk_max": base["atk_max"],
        "can_stagger": base["can_stagger"],            # can it stun the player mid-swing?
        "interrupt_threshold": base["interrupt_threshold"],  # hits-in-wind-up to stagger it
        "block_delay_bonus": base.get("block_delay_bonus",
                                      CFG["combat"]["block_delay_bonus"]),
        "countdown": 0,
    }


def roll_countdown(m):
    return random.randint(m["atk_min"], m["atk_max"])


def render_combat(g, m, status=None):
    render_hud(g)
    print(f" >> {m['name']}")
    print(f"    HP [{bar(m['hp'], m['max_hp'])}] {max(m['hp'], 0)}/{m['max_hp']}")
    cd = max(m["countdown"], 0)
    charge = bar(m["atk_max"] - cd, m["atk_max"], 12, "\u2593", "\u00b7")
    print(f"    STRIKES IN: {cd} tick(s)  [{charge}]")
    print(f"    INTERRUPT:  {g.player['windup_hits']}/{m['interrupt_threshold']} hits"
          + ("" if m["can_stagger"] else "   (this one can't stagger you)"))
    if status:
        print(f"    -- {status}")
    print("-" * 58)


def can_miss(g):
    return g.mode in ("hard", "endless")


def apply_strike(g, m, state):
    """Monster attempts a strike. Returns True if it landed, False if it missed.
    A miss deals nothing and leaves the monster open for a few ticks."""
    if can_miss(g) and random.random() < CFG["combat"]["miss_chance"]:
        m["countdown"] = CFG["combat"]["miss_open_ticks"]
        add_log(g, f"{m['name']} swings wide and misses -- it's wide open!")
        return False
    base = m["dmg"]
    if state == "block_window":
        dmg = int(round(base * (1 - CFG["combat"]["block_reduction"]) * vulnerability(g)))
        m["countdown"] = roll_countdown(m) + m["block_delay_bonus"]
        add_log(g, f"BLOCK! Only {dmg} gets through.")
        if m["block_delay_bonus"]:
            add_log(g, f"It reels -- next strike delayed (+{m['block_delay_bonus']}).")
    else:
        dmg = int(round(base * vulnerability(g)))
        m["countdown"] = roll_countdown(m)
        add_log(g, f"{m['name']} hits you for {dmg}!")
    hurt(g, dmg)
    return True


def advance_combat_ticks(g, m, n, state):
    for _ in range(n):
        spend(g, 1)
        m["countdown"] -= 1
        if m["countdown"] <= 0:
            apply_strike(g, m, state)


def do_attack(g, m):
    for _ in range(CFG["tick_costs"]["attack"]):
        spend(g, 1)
        m["countdown"] -= 1
        if m["countdown"] <= 0:                       # monster's strike resolves now
            hit = apply_strike(g, m, "attack_windup")
            if hit and m["can_stagger"]:
                g.player["stunned"] = CFG["combat"]["stun_ticks"]
                g.player["windup_hits"] = 0           # being staggered breaks your streak
                add_log(g, "Caught mid-swing -- staggered!")
                return                                # swing cancelled
            # otherwise (small monster's hit, or a miss) your swing continues
    # your swing lands -- but in the harder modes it can whiff
    if can_miss(g) and random.random() < CFG["combat"]["miss_chance"]:
        g.player["stunned"] = CFG["combat"]["miss_open_ticks"]
        g.player["windup_hits"] = 0
        add_log(g, "You swing and miss -- you're left wide open!")
        return
    dmg = g.player["dph"]
    crit = random.random() < g.player["crit"]
    if crit:
        dmg = int(dmg * CFG["crit_mult"])
    m["hp"] -= dmg
    add_log(g, f"You hit {m['name']} for {dmg}" + (" (CRIT!)" if crit else "") + ".")
    if m["hp"] <= 0:
        return
    if m["countdown"] > 0:                             # the hit landed while it was winding up
        g.player["windup_hits"] += 1
        if g.player["windup_hits"] >= m["interrupt_threshold"]:
            m["countdown"] = roll_countdown(m)
            g.player["windup_hits"] = 0
            add_log(g, f"You batter {m['name']} out of its wind-up -- attack interrupted!")


def do_block(g, m):
    add_log(g, "You raise your guard.")
    for _ in range(CFG["tick_costs"]["block_window"]):
        spend(g, 1)
        m["countdown"] -= 1
        if m["countdown"] <= 0:
            apply_strike(g, m, "block_window")
    for _ in range(CFG["tick_costs"]["block_cooldown"]):   # recovery: full damage
        spend(g, 1)
        m["countdown"] -= 1
        if m["countdown"] <= 0:
            apply_strike(g, m, "block_cooldown")


def do_wait(g, m):
    advance_combat_ticks(g, m, CFG["tick_costs"]["wait"], "idle")
    add_log(g, "You wait, watching for an opening.")


def do_flee(g, m):
    spend(g, CFG["tick_costs"]["flee"])
    add_log(g, "You turn and run!")
    if random.random() < CFG["combat"]["flee_hit_chance"]:
        dmg = int(round(m["dmg"] * vulnerability(g)))
        add_log(g, f"A parting blow catches you ({dmg})!")
        hurt(g, dmg)
    return True


def combat_item(g, m):
    advance_combat_ticks(g, m, CFG["tick_costs"]["item_open"], "idle")
    if m["hp"] <= 0:
        return
    render_combat(g, m, status="Rummaging in your pack...")
    iid = choose_item(g)
    if iid is None:
        add_log(g, "You shut your pack.")
        return
    advance_combat_ticks(g, m, CFG["tick_costs"]["item_use"], "idle")
    consume(g, iid)


def combat(g, m, ambush=False, pre_crit=False, allow_flee=True):
    """Returns 'win' or 'fled'. Death / timeout raise out of here."""
    m["countdown"] = roll_countdown(m)
    g.player["windup_hits"] = 0
    if ambush:
        add_log(g, f"The {m['name']} strikes first!")
        apply_strike(g, m, "idle")
    if pre_crit:
        dmg = int(g.player["dph"] * CFG["crit_mult"])
        m["hp"] -= dmg
        add_log(g, f"You strike first -- CRITICAL {dmg}!")

    while True:
        if m["hp"] <= 0:
            return "win"

        if g.player["stunned"] > 0:
            render_combat(g, m, status=f"STUNNED ({g.player['stunned']} ticks)")
            pause("  (press Enter -- you are staggered)")
            while g.player["stunned"] > 0:
                advance_combat_ticks(g, m, 1, "idle")
                g.player["stunned"] -= 1
                if m["hp"] <= 0:
                    return "win"
            continue

        render_combat(g, m)
        opts = ["a", "b", "w", "i"] + (["f"] if allow_flee else [])
        menu = "[A]ttack  [B]lock  [W]ait  [I]tem" + ("  [F]lee" if allow_flee else "")
        c = ask("  " + menu + " : ", opts)
        if c == "a":
            do_attack(g, m)
        elif c == "b":
            do_block(g, m)
        elif c == "w":
            do_wait(g, m)
        elif c == "i":
            combat_item(g, m)
        elif c == "f" and allow_flee:
            if do_flee(g, m):
                return "fled"


# --------------------------------------------------------------------------- #
#  Rooms.  Each handler returns "advance" (took the progression door) or
#  "back" (returned to the junction). Death / timeout raise out.
#  "advance" handlers spend the progression move themselves; "back" does not
#  (the junction charges the return move + rolls the return ambush).
# --------------------------------------------------------------------------- #

def proceed(g):
    spend(g, CFG["tick_costs"]["move"])
    return "advance"


def _post_options(extra_label, extra_keys):
    keys = list(extra_keys) + ["p", "b", "i"]
    menu = (extra_label + ", " if extra_label else "") + \
           "[P]roceed, [B]ack, [I]nventory"
    return keys, menu


def room_monster(g, kind):
    m = make_monster(g, kind)
    render_hud(g)
    print(f" You step through the door -- a {m['name']} lunges from the dark!")
    pause()
    if combat(g, m, allow_flee=True) == "fled":
        add_log(g, f"You broke away from the {m['name']}.")
        return "back"
    g.stats["monsters_killed"] += 1
    add_log(g, f"You slay the {m['name']}.")
    looted = False
    while True:
        render_hud(g)
        print(f" The {m['name']} lies dead. A passage leads onward.")
        if looted:
            keys, menu = _post_options("", [])
        else:
            keys, menu = _post_options("[S]earch the corpse", ["s"])
        c = ask("  " + menu + "? ", keys)
        if c == "s" and not looted:
            spend(g, CFG["tick_costs"]["search"])
            g.stats["searches"] += 1
            add_log(g, f"You search the corpse and find: {give_item(g, roll_loot(g))}!")
            looted = True
        elif c == "p":
            return proceed(g)
        elif c == "b":
            return "back"
        elif c == "i":
            inventory_menu(g)


def room_chest(g):
    # A single chest is always safe and always holds an item. You can search to
    # confirm it's safe and then open it (or not), or just grab it blindly.
    searched = False
    looted = False
    desc = DATA["chest_encounters"]["single"]["description"]
    while True:
        render_hud(g)
        print(" " + desc + ("  (you've checked it: no traps)" if searched and not looted else ""))
        if looted:
            keys, menu = _post_options("", [])
        elif searched:
            keys, menu = _post_options("[O]pen it", ["o"])
        else:
            keys, menu = _post_options("[S]earch the chest, [G]rab it (open blindly)",
                                       ["s", "g"])
        c = ask("  " + menu + "? ", keys)
        if c == "s" and not searched and not looted:
            spend(g, CFG["tick_costs"]["search"])
            g.stats["searches"] += 1
            add_log(g, "You check the chest over -- no traps. Safe to open.")
            searched = True
        elif c == "o" and searched and not looted:
            g.stats["chests_opened"] += 1
            add_log(g, f"You open the chest: {give_item(g, roll_loot(g))}!")
            looted = True
        elif c == "g" and not searched and not looted:
            g.stats["chests_opened"] += 1
            add_log(g, f"You throw the lid open: {give_item(g, roll_loot(g))}!")
            looted = True
        elif c == "p":
            return proceed(g)
        elif c == "b":
            return "back"
        elif c == "i":
            inventory_menu(g)


def room_dual_chest(g):
    desc = DATA["chest_encounters"]["dual"]["description"]
    thr = CFG["loot"]["dual_chest_trapped_threshold"]
    chests = [{"trapped": random.randint(0, 9) >= thr} for _ in range(2)]
    resolved = False
    while True:
        render_hud(g)
        print(" " + desc)
        if resolved:
            keys, menu = _post_options("", [])
        else:
            keys, menu = _post_options("[S]earch both, [G]rab both blindly", ["s", "g"])
        c = ask("  " + menu + "? ", keys)
        if c == "s" and not resolved:
            spend(g, CFG["tick_costs"]["search"])
            g.stats["searches"] += 1
            notes = []
            for ch in chests:
                if ch["trapped"]:
                    notes.append("a trapped chest (avoided)")
                else:
                    g.stats["chests_opened"] += 1
                    notes.append(f"a safe chest -> {give_item(g, roll_loot(g))}")
            add_log(g, "You inspect both: " + "; ".join(notes) + ".")
            resolved = True
        elif c == "g" and not resolved:
            for ch in chests:
                g.stats["chests_opened"] += 1
                if ch["trapped"]:
                    dmg = CFG["loot"]["trapped_chest_damage"]
                    add_log(g, f"A chest was trapped! It hits you for {dmg}.")
                    hurt(g, dmg)
                else:
                    add_log(g, f"A chest holds: {give_item(g, roll_loot(g))}!")
            resolved = True
        elif c == "p":
            return proceed(g)
        elif c == "b":
            return "back"
        elif c == "i":
            inventory_menu(g)


def room_trap(g):
    flavor = random.choice(list(DATA["trap_room"].keys()))
    t = DATA["trap_room"][flavor]
    disarmed = False
    while True:
        render_hud(g)
        print(" " + t["description"])
        if flavor == "false_fountain" and not disarmed:
            keys = ["d", "s", "p", "b", "i"]
            menu = "[D]rink, [S]earch, [P]roceed, [B]ack, [I]nventory"
        elif disarmed:
            keys, menu = _post_options("", [])
        else:
            keys, menu = _post_options("[S]earch the room", ["s"])
        c = ask("  " + menu + "? ", keys)
        if c == "s" and not disarmed:
            spend(g, CFG["tick_costs"]["search"])
            g.stats["searches"] += 1
            g.stats["traps_disarmed"] += 1
            add_log(g, t["search_result"])
            disarmed = True
        elif c == "d" and flavor == "false_fountain" and not disarmed:
            dmg = int(round(CFG["rewards"]["false_fountain_damage"] * vulnerability(g)))
            add_log(g, t["trigger_text"] + f" ({dmg} damage)")
            g.stats["traps_sprung"] += 1
            hurt(g, dmg)
            disarmed = True
        elif c == "p":
            if not disarmed:
                if flavor == "false_fountain":
                    pass  # walking past without drinking is safe
                elif flavor == "no_exit":
                    drain = t.get("tick_drain", 25)
                    add_log(g, t["trigger_text"] + f" (-{drain} ticks)")
                    g.stats["traps_sprung"] += 1
                    spend(g, drain)
                else:
                    dmg = int(round(t["damage"] * vulnerability(g)))
                    add_log(g, t["trigger_text"] + f" ({dmg} damage)")
                    g.stats["traps_sprung"] += 1
                    hurt(g, dmg)
            return proceed(g)
        elif c == "b":
            return "back"
        elif c == "i":
            inventory_menu(g)


def room_fountain(g):
    f = DATA["safe_rooms"]["fountain"]
    drunk = False
    while True:
        render_hud(g)
        print(" " + f["description"])
        if drunk:
            keys, menu = _post_options("", [])
        else:
            keys, menu = _post_options("[D]rink (heal)", ["d"])
        c = ask("  " + menu + "? ", keys)
        if c == "d" and not drunk:
            spend(g, CFG["tick_costs"].get("drink_fountain", 1))
            heal = CFG["rewards"]["fountain_heal"]
            before = g.player["hp"]
            g.player["hp"] = min(g.player["max_hp"], g.player["hp"] + heal)
            add_log(g, f["drink_text"] + f" (+{g.player['hp'] - before} HP)")
            drunk = True
        elif c == "p":
            return proceed(g)
        elif c == "b":
            return "back"
        elif c == "i":
            inventory_menu(g)


def room_mimic(g):
    rd = DATA["random_encounter"]["mimic"]
    revealed = False
    while True:
        render_hud(g)
        print(" " + (rd["search_warning"] if revealed else rd["disguise_description"]))
        if revealed:
            keys = ["a", "l", "b", "i"]
            menu = "[A]ttack it first (free crit!), [L]eave it, [B]ack, [I]nventory"
        else:
            keys = ["s", "o", "p", "b", "i"]
            menu = "[S]earch the room, [O]pen the chest, [P]roceed, [B]ack, [I]nventory"
        c = ask("  " + menu + "? ", keys)
        if c == "s" and not revealed:
            spend(g, CFG["tick_costs"]["search"])
            g.stats["searches"] += 1
            add_log(g, "That chest is not a chest...")
            revealed = True
        elif c == "o" and not revealed:
            add_log(g, rd["ambush_text"])
            m = make_monster(g, "mimic")
            if combat(g, m, ambush=True, allow_flee=True) == "fled":
                return "back"
            g.stats["monsters_killed"] += 1
            add_log(g, f"You destroy the {m['name']}. Among its remains: "
                       f"{give_item(g, roll_loot(g))}!")
            return proceed(g)
        elif c == "a" and revealed:
            add_log(g, rd["strike_first_text"])
            m = make_monster(g, "mimic")
            if combat(g, m, pre_crit=True, allow_flee=True) == "fled":
                return "back"
            g.stats["monsters_killed"] += 1
            add_log(g, f"You destroy the {m['name']}. Among its remains: "
                       f"{give_item(g, roll_loot(g))}!")
            return proceed(g)
        elif c == "l" and revealed:
            add_log(g, "You leave the thing where it sits.")
            return proceed(g)
        elif c == "b":
            return "back"
        elif c == "i":
            inventory_menu(g)


def room_search(g):
    s = DATA["safe_rooms"]["search_find"]
    found = False
    while True:
        render_hud(g)
        print(" " + s["description"])
        if found:
            keys, menu = _post_options("", [])
        else:
            keys, menu = _post_options("[S]earch the room", ["s"])
        c = ask("  " + menu + "? ", keys)
        if c == "s" and not found:
            spend(g, CFG["tick_costs"]["search"])
            g.stats["searches"] += 1
            add_log(g, s["search_result"] + f" ({give_item(g, roll_loot(g))})")
            found = True
        elif c == "p":
            return proceed(g)
        elif c == "b":
            return "back"
        elif c == "i":
            inventory_menu(g)


def room_empty(g):
    e = DATA["safe_rooms"]["red_herring"]
    searched = False
    while True:
        render_hud(g)
        print(" " + e["description"])
        if searched:
            keys, menu = _post_options("", [])
        else:
            keys, menu = _post_options("[S]earch the room", ["s"])
        c = ask("  " + menu + "? ", keys)
        if c == "s" and not searched:
            spend(g, CFG["tick_costs"]["search"])
            g.stats["searches"] += 1
            add_log(g, e["search_result"])
            searched = True
        elif c == "p":
            return proceed(g)
        elif c == "b":
            return "back"
        elif c == "i":
            inventory_menu(g)


_ROOM_DISPATCH = {
    0: room_chest,
    1: room_trap,
    3: room_fountain,
    4: room_mimic,
    5: room_search,
    7: room_dual_chest,
    9: room_empty,
}


def enter_room(g, digit):
    if digit in (2, 6, 8):
        return room_monster(g, {2: "small", 6: "medium", 8: "large"}[digit])
    return _ROOM_DISPATCH[digit](g)


# --------------------------------------------------------------------------- #
#  Ambush, junctions, bosses, exit
# --------------------------------------------------------------------------- #

def weighted_monster(g):
    w = CFG["ambush"]["monster_weights"]
    kinds = list(w.keys())
    return random.choices(kinds, weights=[w[k] for k in kinds], k=1)[0]


def maybe_ambush(g, event):
    """event: 'enter_room' or 'return_decision'."""
    if g.mode == "easy":
        chance = CFG["ambush"]["easy_backtrack_chance"] if event == "return_decision" else 0
    elif g.mode == "hard":
        chance = CFG["ambush"]["hard_entry_chance"]
    else:
        chance = CFG["ambush"]["endless_entry_chance"]
    if not chance or random.random() >= chance:
        return

    m = make_monster(g, weighted_monster(g))
    g.stats["ambushes"] += 1
    render_hud(g)
    print(" " + DATA["random_encounter"]["wandering"]["ambush_text"]
          + f" ({m['name']})")
    pause()
    outcome = combat(g, m, ambush=True, allow_flee=True)
    if outcome == "win":
        g.stats["monsters_killed"] += 1
        add_log(g, f"You put down the {m['name']}.")
        render_hud(g)
        if ask("  Search the fallen creature? [Y]es / [N]o ", ["y", "n"]) == "y":
            spend(g, CFG["tick_costs"]["search"])
            g.stats["searches"] += 1
            if random.random() < CFG["loot"]["drop_chance_monster"]:
                add_log(g, f"You find: {give_item(g, roll_loot(g))}!")
            else:
                add_log(g, "Nothing worth taking.")
    elif outcome == "fled":
        add_log(g, "You slip away from the ambush.")


def decision_room(g, pair):
    left, right = pair[0], pair[1]
    while True:
        render_hud(g)
        print(" You reach a junction. Two identical doors face you -- left and right.")
        c = ask("  Go [L]eft, [R]ight, [S]earch the doors, or open [P]ack? ",
                ["l", "r", "s", "p"])
        if c in ("l", "r"):
            spend(g, CFG["tick_costs"]["move"])
            maybe_ambush(g, "enter_room")
            digit = int(left if c == "l" else right)
            if enter_room(g, digit) == "advance":
                return
            spend(g, CFG["tick_costs"]["move"])      # walk back to the junction
            maybe_ambush(g, "return_decision")
        elif c == "s":
            spend(g, CFG["tick_costs"]["search"])
            g.stats["searches"] += 1
            add_log(g, "Two identical doors. Searching them tells you nothing.")
        elif c == "p":
            inventory_menu(g)


def boss_room(g):
    b = DATA["boss_room"]
    m = make_monster(g, "boss")
    render_hud(g)
    print(" " + b["intro"])
    pause()
    add_log(g, f"BOSS: {m['name']}!")
    combat(g, m, allow_flee=False)
    g.stats["bosses_killed"] += 1
    g.player["hp"] = g.player["max_hp"]
    g.ticks += CFG["rewards"]["boss_tick_bonus"]
    add_log(g, b["victory"].format(name=m["name"]))
    add_log(g, b["reward_text"].format(bonus=CFG["rewards"]["boss_tick_bonus"]))
    render_hud(g)
    print(" " + b["victory"].format(name=m["name"]))
    print(" " + b["reward_text"].format(bonus=CFG["rewards"]["boss_tick_bonus"]))
    pause()
    looted = False
    while True:
        render_hud(g)
        print(f" The {m['name']} lies broken. Something glints among its remains.")
        if looted:
            keys, menu = ["p", "i"], "[P]roceed, [I]nventory"
        else:
            keys, menu = ["s", "p", "i"], "[S]earch the remains, [P]roceed, [I]nventory"
        c = ask("  " + menu + "? ", keys)
        if c == "s" and not looted:
            spend(g, CFG["tick_costs"]["search"])
            g.stats["searches"] += 1
            names = [give_item(g, iid) for iid in CFG["rewards"]["boss_loot"]]
            add_log(g, "Among the remains: " + " and ".join(names) + "!")
            looted = True
        elif c == "p":
            return
        elif c == "i":
            inventory_menu(g)


def show_exit(g):
    w = DATA["win_exit"]
    render_hud(g)
    print()
    print("   " + w["title"])
    print()
    print("   " + w["text"])
    print()
    pause()


# --------------------------------------------------------------------------- #
#  Map generation
# --------------------------------------------------------------------------- #

def gen_body(n_digits, allow_99=False, start_pair=0):
    mpb = CFG["generation"].get("min_pairs_before_boss", 0)
    seq = []
    pair_i = start_pair
    for _ in range(0, n_digits, 2):
        while True:
            a, b = str(random.randint(0, 9)), str(random.randint(0, 9))
            if a + b == "99" and not allow_99:
                continue
            if a == b and pair_i < mpb:          # optionally hold bosses back
                continue
            break
        seq += [a, b]
        pair_i += 1
    return seq


def gen_easy():
    return gen_body(CFG["generation"]["easy_digits"]) + ["9", "9"]


def gen_hard():
    seq = gen_body(CFG["generation"]["hard_digits"])
    while True:                                   # extend until a 99 exit appears
        a, b = str(random.randint(0, 9)), str(random.randint(0, 9))
        seq += [a, b]
        if a + b == "99":
            break
    return seq


def gen_endless_start():
    return gen_body(40)


def ensure_length(g, needed):
    if g.mode != "endless":
        return
    while len(g.seq) < needed:
        a, b = str(random.randint(0, 9)), str(random.randint(0, 9))
        if a + b == "99":                         # endless never ends on an exit
            continue
        g.seq += [a, b]


def pair_at(g, idx):
    pos = idx * 2
    ensure_length(g, pos + 2)
    if pos + 1 >= len(g.seq):
        return None
    return g.seq[pos] + g.seq[pos + 1]


def parse_typed(raw, mode):
    digits = [c for c in raw if c.isdigit()]
    need = CFG["generation"]["min_typed_digits"]
    if len(digits) < need:
        return None, f"Seed needs at least {need} digits (you gave {len(digits)})."
    if len(digits) % 2 == 1:
        digits.append(str(random.randint(0, 8)))   # pad even, never create a 99
    warn = None
    for i in range(0, len(digits) - 1, 2):
        if digits[i] + digits[i + 1] == "99":
            warn = (f"Heads up: your seed has an exit (99) at room {i // 2 + 1} -- "
                    "the run will end there.")
            break
    if mode in ("easy", "hard"):
        has_exit = any(digits[i] + digits[i + 1] == "99"
                       for i in range(0, len(digits) - 1, 2))
        if not has_exit:
            digits += ["9", "9"]
    return digits, warn


# --------------------------------------------------------------------------- #
#  Top-level game loop
# --------------------------------------------------------------------------- #

def run_game(g):
    idx = 0
    try:
        while True:
            pair = pair_at(g, idx)
            if pair is None or pair == "99":
                show_exit(g)
                return "win"
            if pair[0] == pair[1]:
                boss_room(g)
                g.stats["rooms_cleared"] += 1
            else:
                decision_room(g, pair)
                g.stats["rooms_cleared"] += 1
            idx += 1
    except PlayerDead:
        return "dead"
    except OutOfTime:
        return "timeout"


# --------------------------------------------------------------------------- #
#  Menus / framing
# --------------------------------------------------------------------------- #

def choose_mode():
    clear()
    print("=" * 58)
    print("  THE BRANCHING HALLS")
    print("  a tick-based corridor crawler")
    print("=" * 58)
    print()
    print("  Every junction has two identical doors. Behind each waits a")
    print("  monster, a trap, a chest, a fountain -- or nothing at all.")
    print("  SEARCH to learn the truth, but every action you take burns")
    print("  the ticks you have left. Reach the exit before your time")
    print("  or your blood runs out.")
    print()
    print("  Difficulty:")
    print("   [E]asy    -- 40-room seed, exit guaranteed at the end.")
    print("   [H]ard    -- 60-room seed, exit hidden somewhere beyond,")
    print("                and wanderers ambush you on every move.")
    print("   e[N]dless -- no exit. See how deep you can get.")
    print()
    return {"e": "easy", "h": "hard", "n": "endless"}[
        ask("  Choose [E] / [H] / [N]: ", ["e", "h", "n"])]


def choose_seed(mode):
    print()
    print("  Map seed:")
    print("   [G]enerate a fresh random map")
    print("   [T]ype your own seed (digits)")
    if ask("  Choose [G] / [T]: ", ["g", "t"]) == "g":
        return {"easy": gen_easy, "hard": gen_hard,
                "endless": gen_endless_start}[mode]()
    while True:
        try:
            raw = input("  Enter seed digits: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            raise SystemExit(0)
        seq, warn = parse_typed(raw, mode)
        if seq is None:
            print("  " + warn)
            continue
        if warn:
            print("  " + warn)
        return seq


def end_screen(g, outcome):
    render_hud(g)
    print()
    if outcome == "win":
        print("  ***  YOU ESCAPED THE BRANCHING HALLS  ***")
    elif outcome == "dead":
        print("  ***  YOU DIED IN THE DARK  ***")
    else:
        print("  ***  TIME RAN OUT -- the halls keep you  ***")
    s = g.stats
    print()
    print(f"   Rooms cleared : {s['rooms_cleared']}")
    print(f"   Monsters slain: {s['monsters_killed']}")
    print(f"   Bosses slain  : {s['bosses_killed']}")
    print(f"   Ambushes      : {s['ambushes']}")
    print(f"   Chests opened : {s['chests_opened']}")
    print(f"   Items found   : {s['items_found']}")
    print(f"   Traps sprung  : {s['traps_sprung']}  (disarmed: {s['traps_disarmed']})")
    print(f"   Searches      : {s['searches']}")
    print(f"   Ticks left    : {g.ticks}")
    print(f"   Final HP      : {g.player['hp']}/{g.player['max_hp']}")
    print()
    seed_str = "".join(g.seq[:80])
    print(f"   Seed: {seed_str}{'...' if len(g.seq) > 80 else ''}")
    print()


def main():
    load_all()
    while True:
        mode = choose_mode()
        seq = choose_seed(mode)
        g = Game(mode, seq)
        add_log(g, "You enter the labyrinth.")
        outcome = run_game(g)
        end_screen(g, outcome)
        if ask("  Play again? [Y] / [N]: ", ["y", "n"]) == "n":
            print("  Farewell.")
            return


if __name__ == "__main__":
    main()
