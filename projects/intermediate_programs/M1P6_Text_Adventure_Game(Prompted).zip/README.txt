THE BRANCHING HALLS  (project M1P6)
===================================

A tick-based text dungeon crawler. Pure Python standard library -- no installs.

HOW TO RUN
----------
Keep M1P6.py and all the .json files together in ONE folder, then:

    python3 M1P6.py

The script loads its data files from its own folder, so don't separate them.

THE IDEA
--------
Your map is a string of digit pairs. Each pair is a junction with two identical
doors (left = first digit, right = second). Behind each digit is a room:

    0 chest        1 trap         2 small monster   3 fountain (heal)
    4 mimic        5 search room  6 medium monster  7 two chests
    8 large monster              9 empty (red herring)

A matched pair (e.g. 33) is a forced BOSS. The pair "99" is the EXIT -- reach it
to win. A single global TICK budget counts down; every action costs ticks, and
combat drains the same budget. You lose at 0 HP or 0 ticks.

  Easy    : 40-digit map, exit guaranteed at the end. No scaling -- flat all run.
  Hard    : 60-digit map, exit hidden further on; wanderers ambush every move,
            and monsters + the damage you take scale up the deeper you go.
  Endless : no exit -- survive as long as you can; scaling ramps faster. Stats at
            the end.

CHESTS, FOUNTAINS, BOSSES
-------------------------
A single chest (0) is always safe: Search to confirm it's clean and then Open it
(or not), or just Grab it blindly. Two chests (7) can each be trapped: Search
both to take only the safe loot, or Grab both and gamble. A real fountain (3) is
a one-time heal; a "false fountain" is a trap that hurts if you drink. A cleared
boss fully heals you and grants bonus ticks, AND can be searched for a guaranteed
Whetstone (+5 damage) and a Major Healing Draught.

DIFFICULTY SCALING (hard / endless)
-----------------------------------
The further you progress, the harder it gets. Monster HP and damage grow per room
cleared, and a "Peril" multiplier raises ALL damage you take (shown in the HUD
once it's above x1.00). Easy stays flat. All of it lives under "scaling" in
config.json -- per-room growth rates and a cap for each difficulty.

COMBAT (timing puzzle, no reflexes)
-----------------------------------
The monster shows "STRIKES IN: N ticks". Pick the action whose tick cost lines
up: Attack (2t), Block (2t window + 2t cooldown, 70% reduction; a block delays
the monster's next hit -- but NOT a boss's), Wait (1t, to nudge your timing),
Item (open + use), Flee (5t, not vs boss).

On hard and endless, attacks have a small chance to MISS -- whoever whiffs (you
or the monster) is left wide open for a few ticks. Easy never misses.

Staggering: if a medium / large / boss hits you mid-attack, you're staggered
(stunned, swing cancelled). SMALL monsters can't stagger you -- you take the hit
but your swing still lands. Interrupting: land a streak of hits during the
monster's wind-up to stagger IT -- 3 for small, 5 medium, 6 large, 7 boss. Being
staggered (or missing) resets your streak, so against the big ones you must block
or time their strike to keep it alive (the HUD shows your INTERRUPT progress).

TUNING
------
Every number lives in config.json (tick budget, HP/damage, all tick costs, drop
weights, ambush odds, difficulty scaling). Monster stats are in monsters.json;
room and item text/values in the other .json files. Change those, not the code,
to rebalance. Want to keep early rooms from being bosses? Set
"min_pairs_before_boss" in config.json above 0.
